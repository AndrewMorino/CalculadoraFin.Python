﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PI_3º_termo
{
    class Pessoas
    {
       public int id;
       public string nome;
       public string telefone;
       public string telefone2;
       public string cidade;
       public string email;
       public string datanasc;
       public string sexo;
       public string Rg;
       public string Cpf;
       public string foto;
       


    }
}
